# if runs
#def main():
 #   pass

#if __name__ == '__main__':
  #  main()

#def add(x, y):
  #  print("x is {} and y is {}". format(x,y))
 #   return x + y

# add(1,3)
#add(y=65, x=3)

#def keywords_args(**args):
    #return args

#print(keywords_args(size=1, weight=90))

#this has file input so you can add it to an array

#print([x for x in [3, 4, 5, 6, 7] if x > 4])


#result = []
#for x in [3, 4, 5, 6, 7]:
 #   if x > 5:
#        result.append(x)
#print(result)

#input("\n\nPress enter to exit program")