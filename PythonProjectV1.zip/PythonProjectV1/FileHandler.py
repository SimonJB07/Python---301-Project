import re

class FileReader:
    @staticmethod
    def file_reader():

        class_file = open('ClassDiagram.txt', 'r').readlines()
        #re.findall(r'class', class_file)
        for line in class_file:
            print(line, end='\n')






# file = FileReader()
FileReader.file_reader()

