

class FileWriter:

    @staticmethod
    def file_writer(class_name, attribute_name, method_name, file_name):
        with open(file_name, "w") as output_file:
            print(f"class {class_name}:", file=output_file)
            # loop
            print(f"      {attribute_name}", file=output_file)
            # loop
            print(f"    def {method_name}(self):", file=output_file)
            print(f"        pass", file=output_file)

