class TempClass:
      ('trisk', 'thss', 'trhe')
    def ('tro', 'fsdjksaf', 'fdsaadf')(self):
        pass
