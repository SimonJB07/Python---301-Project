from Model.set_up_class import SetUp


class FileReader:

    @staticmethod
    def file_reader(file_name):
        with open(file_name, 'r') as diagram_file:
            for line in diagram_file:
                temp_line = line.replace('\n', '').replace(' ', '')
                SetUp.set_up_class(temp_line)
