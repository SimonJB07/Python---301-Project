from Model.replace_value import Replace

class FileFormat:
    """The class's docstring"""

    @staticmethod
    def removing_lines(line):
        """The method's docstring"""
        print(line, end=' ')
        replace_item_list = ['String', 'Integer', 'float']
        # list







