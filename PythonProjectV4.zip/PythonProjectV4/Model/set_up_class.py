from Model.file_writer import FileWriter
from Model.replace_value import Replace

class SetUp:
    attribute_name = 'trisk', 'thss', 'trhe'
    method_name = 'tro', 'fsdjksaf', 'fdsaadf'
    file_name = "Output.py"
    class_name = "TempClass", 'work', 'dam', 'it'

    @staticmethod
    def set_over_string(line):
        print(line, end=' ')
        if 'class' in line:
            class_line = line.replace("class", '')
            python_class_name = class_line.replace('{', '')
            line.set_up_class(python_class_name)

        if '_' in line:
            new_list = line.replace('String', '').replace('Integer', '').replace('void', '')
            if ':' in line:
                method_name = line
            if '()' in line:
                pass


    @staticmethod
    def set_up_class(python_class_name):
        class_layout = python_class_name + ':\n'
        return class_layout

    @staticmethod
    def set_up_method(method_name):
        pass

    FileWriter.file_writer(class_name, attribute_name, method_name, file_name)