

class FileWriter:
    """The class's docstring"""

    @staticmethod
    def file_writer(file_name, overall_content):
        """The method's docstring"""
        with open(file_name, "w") as output_file:
            #fun = ''
            #for lis in attribute_list:
                #fun += ', ' + 'new_' + lis
            for c in overall_content:
                print(f"class {c.value}:", file=output_file)
                print(f"    def __init__(self{c}):", file=output_file)
                # for a in attribute_list:
                print(f"        self.{c.value}: new_{c}", file=output_file)
                print(f"        ", file=output_file)
                # for m in method_list:
                print(f"    def {c.value}(self):", file=output_file)
                print(f"        pass \n", file=output_file)
