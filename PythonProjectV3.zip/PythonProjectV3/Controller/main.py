from Model.file_reader import FileReader
from Model.file_writer import FileWriter
from doctest import testmod
#import unittest

def main():
    FileReader.file_reader()
    FileWriter.file_writer()


if __name__ == '__main__':
    main()
