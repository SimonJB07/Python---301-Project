from Model.format_file import FileFormat


class FileWriter:

    @staticmethod
    def file_writer():
        # class_name, user_filename
        class_name = FileFormat
        user_output = 'method1'
        pass_output = 'pass'
        # exec(file)
        with open("Output.py", "w") as output_file:
            print(f"class {class_name}:", file=output_file)
            print(f"    def {user_output}(self):", file=output_file)
            print(f"        {pass_output}", file=output_file)
