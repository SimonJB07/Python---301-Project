class <class 'Model.format_file.FileFormat'>:
    def method1(self):
        pass
