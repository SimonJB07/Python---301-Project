from Model.file_writer import FileWriter
from Model.replace_value import Replace
from Model.relationship_value import Relationship

class SetUp:
    """The class's docstring"""
    uml_list = []
    class_dict = {}
    class_relationship = []
    attribute_list = []
    method_list = []
    file_name = 'output_file.py'
    overall_content = []

    # {Animals [attribute],[method]}
    # [{'class_name_key', 'value', 'attributes_key', ['', ''], 'methods_key', ['', '']}, {}]

    @staticmethod
    def set_over_string(overall_file):
        """The method's docstring"""
        # Setup.overall_content = str(overall_file)
        # overall = SetUp.overall_string
        for line in overall_file:
            if ('--' or '..') in line:
                SetUp.set_up_relationship(line)
            if 'class' in line:
                SetUp.set_up_class_name(line)
            elif ':' in line:
                SetUp.set_up_attribute_name(line)
            elif '(' in line:
                SetUp.set_up_method_name(line)
            elif '}' in line:
                SetUp.class_dict['relationship_key'] = SetUp.class_relationship
                SetUp.class_dict['attributes_key'] = SetUp.attribute_list
                SetUp.class_dict['methods_key'] = SetUp.method_list
                SetUp.overall_content = SetUp.class_dict
                temp_dict = SetUp.class_dict.copy()
                SetUp.uml_list.append(temp_dict)
                SetUp.class_dict.clear()
                SetUp.class_dict = {}
                SetUp.attribute_list = []
                SetUp.method_list = []
            else:
                pass
        FileWriter.file_writer(SetUp.file_name, SetUp.uml_list)

        #print(SetUp.uml_list)

    @staticmethod
    def set_up_class_name(python_class_name):
        """The method's docstring"""
        class_name = python_class_name.replace("class", '').replace('{', '')
        SetUp.class_dict['class_name_key'] = class_name
        return class_name

    @staticmethod
    def set_up_attribute_name(attribute_name):
        """The method's docstring
        >>> at = 'data_name: str'
        >>>
        >>>
        >>>
        """
        temp_att = SetUp.clear_up_data(attribute_name)
        at = SetUp.reverse_words(temp_att)
        SetUp.attribute_list.append(at)
        # print(at)

    @staticmethod
    def set_up_method_name(method_name):
        """The method's docstring

        """
        temp_met = method_name.replace('void', '')
        met = SetUp.clear_up_data(temp_met).replace('str ', '')
        SetUp.method_list.append(met)

    @staticmethod
    def set_up_relationship(relationship_value):
        """The method's docstring

        """
        temp_rel = SetUp.clean_up_relationship(relationship_value)
        SetUp.class_relationship.append(temp_rel)

    @staticmethod
    def clean_up_relationship(relationship):
        """The method's docstring
        >>> rel = '--'
        """
        rel = relationship.replace('<|--', Relationship.EXTENSION.value) \
            .replace('*--' or '--*', Relationship.COMPOSITION.value) \
            .replace('o--' or '--o', Relationship.AGGREGATION.value) \
            .replace('..', Relationship.INHERITANCE.value) \
            .replace('--', Relationship.ASSOCIATION.value) \
            .replace('-->' or '<--', Relationship.DIRECTED_ASSOCIATION.value) \
            .replace('..>' or '<..', Relationship.DEPENDENCY.value)\
            .replace('..|>', Relationship.IMPLEMENTATION.value) \
            .replace('<--*' or '*-->', Relationship.COMPOSITION_ASSOCIATION.value) \
            .replace('x--' or '--x', Relationship.CONTAINMENT.value)\
            .replace('}--' or '--{', Relationship.CROWS_FEET.value) \
            .replace('^--' or '--^', Relationship.INTERFACE.value)
        return rel

    @staticmethod
    def clear_up_data(data):
        """The method's docstring
        >>> clean_data = 'String'
        """
        clean_data = data.replace('String', Replace.STRING.value)\
            .replace('Integer', Replace.INTEGER.value) \
            .replace('Float', Replace.FLOAT.value) \
            .replace('Boolean', Replace.BOOLEAN.value) \
            .replace('List', Replace.LIST.value) \
            .replace('Tuple', Replace.TUPLE.value) \
            .replace('Dict', Replace.DICT.value)
        return clean_data

    @staticmethod
    def reverse_words(word):
        return ' '.join(reversed(word.split()))


