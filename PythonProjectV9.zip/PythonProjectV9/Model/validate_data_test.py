

class ValidateData:
    """This just handles the data
    and checks to see if it is all there

     """

    @staticmethod
    def validate_test_loader(test_data):
        """if the data load correctly
        >>> class_name == 'classDiagramModel{'
        'DiagramModel{'
        """
        for line in test_data:
            if ('--' or '..') in line:
                pass
            if 'classDiagramModel{' in line:
                pass
            elif ':' in line:
                pass
            elif '(' in line:
                pass
            elif '}' in line:
                pass
            else:
                pass




