from Model.file_writer import FileWriter
from Model.replace_value import Replace
from Model.relationship_value import Relationship


class SetUp:
    """The class's docstring
    >>> SetUp.file_name == 'output_file.py'
    True

    """
    uml_list = []
    class_dict = {}
    class_relationship = []
    attribute_list = []
    method_list = []
    file_setup_name = ''
    overall_content = []

    # {Animals [attribute],[method]}
    # [{'class_name_key', 'value', 'attributes_key', ['', ''], 'methods_key', ['', '']}, {}]

    @staticmethod
    def set_over_string(overall_file):
        """This checks to see if there is a class dict
        >>> SetUp.class_dict == {}
        True
        """
        # Setup.overall_content = str(overall_file)
        # overall = SetUp.overall_string
        for line in overall_file:
            if ('--' or '..') in line:
                SetUp.set_up_relationship(line)
            elif 'class' in line:
                SetUp.set_up_class_name(line)
            elif ':' in line:
                SetUp.set_up_attribute_name(line)
            elif '(' in line:
                SetUp.set_up_method_name(line)
            elif '}' in line:
                SetUp.class_dict['relationship_key'] = SetUp.class_relationship
                SetUp.class_dict['attributes_key'] = SetUp.attribute_list
                SetUp.class_dict['methods_key'] = SetUp.method_list
                SetUp.overall_content = SetUp.class_dict
                temp_dict = SetUp.class_dict.copy()
                SetUp.uml_list.append(temp_dict)
                SetUp.class_dict.clear()
                SetUp.class_dict = {}
                SetUp.attribute_list = []
                SetUp.method_list = []
            else:
                pass
        FileWriter.file_writer(SetUp.file_setup_name, SetUp.uml_list)

        # print(SetUp.uml_list)

    @staticmethod
    def set_up_class_name(python_class_name):
        """this returns the class name
        >>> class_name = 'DiagramModel'
        """
        class_name = python_class_name.replace("class", '').replace('{', '')
        SetUp.class_dict['class_name_key'] = class_name
        return class_name

    @staticmethod
    def set_up_attribute_name(attribute_name):
        """This changes String into the str or the diagram
        >>> SetUp.set_up_attribute_name('String data_name:')
        'str  data_name:'
        >>> SetUp.set_up_attribute_name('List id_number:')
        '[]  id_number:'
        >>> SetUp.set_up_attribute_name('Integer count_students:')
        'int  count_students:'
        """
        temp_att = SetUp.clear_up_data(attribute_name)
        at = SetUp.reverse_words(temp_att)
        SetUp.attribute_list.append(at)
        return temp_att

    @staticmethod
    def set_up_method_name(method_name):
        """this removes the String from the method attributes
        >>> SetUp.set_up_method_name('String name')
        ' name'
        """
        temp_met = method_name.replace('void', '')
        met = SetUp.clear_up_data(temp_met).replace('str ', '')
        SetUp.method_list.append(met)
        return met

    @staticmethod
    def set_up_relationship(relationship_value):
        """this method converts diagram to workable class
        >>> SetUp.set_up_relationship('DiagramModel--TestModel')
        'DiagramModel association TestModel'
        """
        temp_rel = SetUp.clean_up_relationship(relationship_value)
        SetUp.class_relationship.append(temp_rel)
        return temp_rel

    @staticmethod
    def clean_up_relationship(relationship):
        """this picks out the right value for the relationship
        >>> SetUp.clean_up_relationship('<|--')
        ' extension '
        """
        rel = relationship.replace('<|--', Relationship.EXTENSION.value) \
            .replace('*--' or '--*', Relationship.COMPOSITION.value) \
            .replace('o--' or '--o', Relationship.AGGREGATION.value) \
            .replace('..', Relationship.INHERITANCE.value) \
            .replace('--', Relationship.ASSOCIATION.value) \
            .replace('-->' or '<--', Relationship.DIRECTED_ASSOCIATION.value) \
            .replace('..>' or '<..', Relationship.DEPENDENCY.value) \
            .replace('..|>', Relationship.IMPLEMENTATION.value) \
            .replace('<--*' or '*-->', Relationship.COMPOSITION_ASSOCIATION.value) \
            .replace('x--' or '--x', Relationship.CONTAINMENT.value) \
            .replace('}--' or '--{', Relationship.CROWS_FEET.value) \
            .replace('^--' or '--^', Relationship.INTERFACE.value)
        return rel

    @staticmethod
    def clear_up_data(data):
        """this converts to a class diagram str
        >>> SetUp.clear_up_data('String')
        'str '
        >>> SetUp.clear_up_data('Integer')
        'int '
        """
        clean_data = data.replace('String', Replace.STRING.value) \
            .replace('Integer', Replace.INTEGER.value) \
            .replace('Float', Replace.FLOAT.value) \
            .replace('Boolean', Replace.BOOLEAN.value) \
            .replace('List', Replace.LIST.value) \
            .replace('Tuple', Replace.TUPLE.value) \
            .replace('Dict', Replace.DICT.value) \
            .replace('TestModel', 'TestModel')
        data_space = clean_data + ' '
        return data_space

    @staticmethod
    def reverse_words(word):
        """this reverse words in a string
        >>> SetUp.reverse_words('too word')
        'word too'
        """
        return ' '.join(reversed(word.split()))


if __name__ == '__main__':
    import doctest

    doctest.testmod(verbose=True)
