from Model.file_writer import FileWriter
from Model.replace_value import Replace


class SetUp:
    """The class's docstring"""
    attribute_list = []
    method_list = []
    class_dict = {}
    file_name = 'output_file.py'
    overall_string = ''

    # {Animals [attribute],[method]}
    # [{'class_name_key', 'value', 'attributes_key', ['', ''], 'methods_key', ['', '']}, {}]

    @staticmethod
    def set_over_string(overall_file):
        """The method's docstring"""
        # overall_list = str(overall_file)
        # print(overall_file)
        overall = SetUp.overall_string
        # print(overall)
        for line in overall_file:
            if 'class' in line:
                # print(line)
                SetUp.class_dict['class'] = SetUp.set_up_class_name(line)

                if any(':' in s for s in overall_list):
                    SetUp.set_up_attribute_name(class_name)
                    # print(kfjsdkjakfj)
                if any('(' in s for s in overall_list):
                    SetUp.set_up_method_name(overall_list)
                    # print(kjdsakafj)

    @staticmethod
    def set_up_clear_list(overall_string):
        """The method's docstring"""
        overall_string.replace('@startuml', '')
        overall_string.replace('@enduml', '')
        return overall_string

    @staticmethod
    def set_up_class_name(python_class_name):
        """The method's docstring"""
        class_name = str(python_class_name).replace("class", '').replace('{', '')

        SetUp.class_name = class_name
        return class_name

    @staticmethod
    def set_up_attribute_name(attribute_name):
        """The method's docstring"""

        pass

    @staticmethod
    def set_up_method_name(method_name):
        """The method's docstring"""
        method_ame = str(method_name).replace('String',
                                              Replace.STRING.value).replace('Integer',
                                                                            Replace.INTEGER.value).replace('void', '')
        print(method_ame)

    FileWriter.file_writer(class_dict, attribute_list, method_list, file_name)
