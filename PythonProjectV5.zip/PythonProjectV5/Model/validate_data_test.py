

class ValidateData:
    """This just handles the data
    and checks to see if it is all there
     """

    @staticmethod
    def validate_test_loader(test_data):
        """this give the user feedback on if the data
        load correctly by returning true"""
        if test_data.count('@startuml') == 1:
            if test_data.count('@enduml') == 1:
                return True


