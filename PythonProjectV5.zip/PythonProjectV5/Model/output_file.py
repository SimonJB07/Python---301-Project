class Animals:
    def __init__(self, new_lick, new_meow, new_squeak):
        self.lick: new_lick
        self.meow: new_meow
        self.squeak: new_squeak
        
    def dog(self):
        pass 

    def cat(self):
        pass 

    def mice(self):
        pass 

