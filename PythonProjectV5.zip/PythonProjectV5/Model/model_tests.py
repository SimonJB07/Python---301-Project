import unittest


class MyTestCase(unittest.TestCase):
    """The class's docstring"""
    def test_something(self):
        """The method's docstring"""
        self.assertEqual(True, False)


if __name__ == '__main__':
    unittest.main()
