

class FileWriter:
    """The class's docstring"""

    @staticmethod
    def file_writer(class_dict, attribute_list, method_list, file_name):
        """The method's docstring"""
        with open(file_name, "w") as output_file:
            fun = ''
            for lis in attribute_list:
                fun += ', ' + 'new_' + lis
            for c in class_dict:
                print(f"class {c}:", file=output_file)
                print(f"    def __init__(self{fun}):", file=output_file)
                for a in attribute_list:
                    print(f"        self.{a}: new_{a}", file=output_file)
                print(f"        ", file=output_file)
                for m in method_list:
                    print(f"    def {m}(self):", file=output_file)
                    print(f"        pass \n", file=output_file)
