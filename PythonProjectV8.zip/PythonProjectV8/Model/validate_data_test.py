

class ValidateData:
    """This just handles the data
    and checks to see if it is all there

     """

    @staticmethod
    def validate_test_loader(test_data):
        """if the data load correctly
        >>>
        >>> count = True
        """
        print(test_data)
        count = bool
        for i in test_data:

            if test_data.count('@startuml') == 1:
                if test_data.count('@enduml') == 1:
                    return True
            if 'DiagramModel' in test_data:
                test1 = True
            if 'data_name' in test_data:
                count = True

