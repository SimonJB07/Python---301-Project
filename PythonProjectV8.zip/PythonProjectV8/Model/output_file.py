
class DiagramModel:
    def __inti__(self):
        self.diagramModel: TestModel
        self.data_name: str
        self.id_number: []
        self.count_students: int
        
    @staticmethod
    def get_id():
        pass

    @staticmethod
    def get_name(name):
        pass

    @staticmethod
    def set_name():
        pass


class TestModel:
    def __inti__(self):
        self.data_name: str
        self.id_number: []
        self.count_students: int
        
    @staticmethod
    def get_id():
        pass

    @staticmethod
    def get_name(name):
        pass

    @staticmethod
    def set_name():
        pass

