
class SetUp:

    @staticmethod
    def set_up_class(python_class_name):
        class_layout = python_class_name + ':\n'
        return class_layout

    @staticmethod
    def set_up_method(python_method_name):
        pass
