from Model.format_file import FileFormat


class FileReader:

    @staticmethod
    def file_reader():
        with open('ClassDiagram.txt', 'r') as diagram_file:
            for line in diagram_file:
                temp_line = line.replace('\n', '').replace(' ', '')
                FileFormat.removing_lines(temp_line)
