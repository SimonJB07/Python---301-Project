class_value = {'String': 'str', 'Integer': 'int', 'Floating-Point Numbers': 'float',
               'Boolean': 'bool', 'List': '[]', 'Tuple': '()', 'Dictionaries': '{:}'}


class FileFormat:
    """The class's docstring"""

    def __init__(self):
        self.python_class_name = ""
    # self.my_name = "unknown"

    @staticmethod
    def removing_lines(line):
        """The method's docstring"""
        print(line, end=' ')
        # replace_item_list = [' ', 'class', '{', '}', '\n']
        # list

        if 'class' in line:
            class_line = line.replace("class", '')
            python_class_name = class_line.replace('{', '')

        if '{' in line:
            pass
            #print(python_class_name)

        elif '}' in line:
            pass
            line.set_up_class(python_class_name)

        elif 'String' in line:
            function_name = line.replace("String", '')
            set_up_function(function_name)
            # print(function_name)
    
    @staticmethod
    def get_class():
        pass



def set_up_class(python_class_name):
    """The function's docstring"""
    class_layout = python_class_name + ':\n'
    return class_layout


def set_up_function(function_name):
    """The function's docstring"""
    pass
