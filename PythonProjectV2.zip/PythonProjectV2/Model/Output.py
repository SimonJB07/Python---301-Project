class None:
    def method1(self):
        pass
